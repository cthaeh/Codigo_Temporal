/*SOCKETS SERVIDOR*/

/* Includes del sistema */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>

#include "servidor.h"

#include "comunes.h"


/*ACEPTAR CLIENTE*/
int Acepta_Conexion_Cliente(int Descriptor) {
	socklen_t Longitud_Cliente;
	struct sockaddr Cliente;
	int Hijo;

	/*ACCEPT = ACEPTAR CLIENTE*/
	Longitud_Cliente = sizeof(Cliente);
	Hijo = accept(Descriptor, &Cliente, &Longitud_Cliente);
	if (Hijo == -1)
		return -1;

	/*Se devuelve el file descriptor en el que esta "enchufado" el cliente.*/
	return Hijo;
}

/*ABRE SOCKET TCP/IP, se pasa por parametro PUERTO de escucha del Servidor*/
int Abre_Socket_Inet(int PUERTO) {
	struct sockaddr_in Direccion;
	int Descriptor;

	/* Se abre el socket */
	Descriptor = socket(AF_INET, SOCK_STREAM, 0);
	if (Descriptor == -1)
		return -1;

	/* BUROCRACIA DE SOCKETS, INNADDR_ANY ES LA MAQUINA EN LA QUE SE EJECUTA EL PROGRAMA ME MANTENGO EN ESCUCHA EN EL PUERTO */
	Direccion.sin_family = AF_INET;
	Direccion.sin_port = htons(PUERTO);
	Direccion.sin_addr.s_addr = INADDR_ANY;

	int activado = 1;
	setsockopt(Descriptor, SOL_SOCKET, SO_REUSEADDR, &activado, sizeof(activado));

	if (bind(Descriptor, (struct sockaddr *) &Direccion, sizeof(Direccion))
			== -1) {
		close(Descriptor);
		return -1;
	}

	/* ME MANTENGO EN ESCUCHA DE CONEXIONES */
	if (listen(Descriptor, MAX_CLIENTES) == -1) {
		close(Descriptor);
		return -1;
	}

	/* DEVUELVO EL FILE DESCRIPTOR, SOCKET = INT */
	return Descriptor;
}

/* Crea un nuevo socket cliente. Se le pasa el socket servidor y el array de clientes, con el número de clientes ya conectados. */
int nuevoCliente (int servidor, int *clientes, int *nClientes)
{
	/* Acepta la conexión con el cliente, guardándola en el array */
	clientes[*nClientes] = Acepta_Conexion_Cliente (servidor);
	(*nClientes)++;

	/* Si se ha superado el maximo de clientes, se cierra la conexión, se deja todo como estaba y se vuelve. */
	if ((*nClientes) >= MAX_CLIENTES)
	{
		close (clientes[(*nClientes) -1]);
		(*nClientes)--;
		return -1;
	}

	/* Envía su número de cliente al cliente */
	escribeSocket (clientes[(*nClientes)-1], (char *)nClientes, sizeof(int));

	/* Escribe en pantalla que ha aceptado al cliente y vuelve */

	return clientes[(*nClientes)-1];
}

/* Función que devuelve el valor máximo en la tabla. Supone que los valores válidos de la tabla son positivos y mayores que 0.
   Devuelve 0 si n es 0 o la tabla es NULL */
int dameMaximo (int *tabla, int n)
{
	int i;
	int max;

	if ((tabla == NULL) || (n<1))
		return 0;

	max = tabla[0];
	for (i=0; i<n; i++)
		if (tabla[i] > max)
			max = tabla[i];

	return max;
}

/* Busca en array todas las posiciones con -1 y las elimina, copiando encima las posiciones siguientes.
   Ejemplo, si la entrada es (3, -1, 2, -1, 4) con *n=5 a la salida tendremos (3, 2, 4) con *n=3 */
void compactaClaves (int *tabla, int *n)
{
	int i,j;

	if ((tabla == NULL) || ((*n) == 0))
		return;

	j=0;
	for (i=0; i<(*n); i++)
	{
		if (tabla[i] != -1)
		{
			tabla[j] = tabla[i];
			j++;
		}
	}

	*n = j;
}
