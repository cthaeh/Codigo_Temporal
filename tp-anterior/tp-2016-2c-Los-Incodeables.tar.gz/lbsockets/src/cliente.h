/*BIBLIOTECA SOCKETS CLIENTE*/
#ifndef CLIENTE_H_
#define CLIENTE_H_

int Abre_Conexion_Inet (char *Host_Servidor, int PUERTO);

#endif
