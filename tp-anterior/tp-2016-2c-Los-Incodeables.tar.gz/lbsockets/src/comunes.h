/*BIBLIOTECA SOCKETS SERVIDOR*/
#ifndef COMUNES_H
#define COMUNES_H

int leeSocket (int fd, char *Datos, int Longitud);
int escribeSocket (int fd, char *Datos, int Longitud);

#endif
