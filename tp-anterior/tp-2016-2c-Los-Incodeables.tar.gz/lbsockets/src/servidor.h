/*BIBLIOTECA SOCKETS SERVIDOR*/
#ifndef SERVIDOR_H
#define SERVIDOR_H

#define MAX_CLIENTES 100

int Abre_Socket_Inet (int PUERTO);
int Acepta_Conexion_Cliente (int Descriptor);
int nuevoCliente (int servidor, int *clientes, int *nClientes);
int dameMaximo (int *tabla, int n);
void compactaClaves (int *tabla, int *n);

#endif
