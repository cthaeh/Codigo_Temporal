/*SOCKETS CLIENTE*/

/*
 * Includes del sistema
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>

#include "cliente.h"

/* Conecta con un servidor remoto a traves de socket INET */
int Abre_Conexion_Inet(char *Host_Servidor, int PUERTO) {
	struct sockaddr_in Direccion;
	struct servent *Puerto;
	struct hostent *Host;
	int Descriptor;

	Puerto = htons(PUERTO);

	Host = gethostbyname(Host_Servidor);
	if (Host == NULL)
		return -1;

	Direccion.sin_family = AF_INET;
	Direccion.sin_addr.s_addr = ((struct in_addr *) (Host->h_addr))->s_addr;
	Direccion.sin_port = Puerto;

	Descriptor = socket(AF_INET, SOCK_STREAM, 0);
	if (Descriptor == -1)
		return -1;

	if (connect(Descriptor, (struct sockaddr *) &Direccion, sizeof(Direccion))
			== -1) {
		return -1;
	}

	return Descriptor;
}

