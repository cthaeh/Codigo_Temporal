#include <stdio.h>
#include <stdlib.h>
#include <commons/collections/list.h>
#include <assert.h>
#include <string.h>
#include <commons/string.h>
#include <cspecs/cspec.h>
#include <stdbool.h>
#include "entrenador.h"
#define MAX_RECURSOS 20



/*esto es para la hardcodeada de datos*/



t_list * datosHCPokenests(){

	/*defino mi lista de pokenests*/

	t_list * pokenestes = list_create(); /*ok*/
	list_clean(pokenestes);

	/*defino un par de pokenests*/
	pokenest * nestA = malloc(sizeof(pokenest));
	nestA->simbolo= "@";
	nestA->cantidad=3;
	/* agrego los poke a la lista */

	 list_add(pokenestes,nestA);

		pokenest * nestB = malloc(sizeof(pokenest));
		nestA->simbolo= "%";
		nestA->cantidad=2;
		/* agrego los poke a la lista */

		 list_add(pokenestes,nestB);

	pokenest * nestC = malloc(sizeof(pokenest));
			nestC->simbolo= "=";
			nestC->cantidad=3;
			/* agrego los poke a la lista */

			 list_add(pokenestes,nestC);

	pokenest * nestD = malloc(sizeof(pokenest));
				nestD->simbolo= "&";
				nestD->cantidad=2;
				/* agrego los poke a la lista */

				 list_add(pokenestes,nestD);

					pokenest * nestE = malloc(sizeof(pokenest));
							nestE->simbolo= "?";
							nestE->cantidad=3;
							/* agrego los poke a la lista */

							 list_add(pokenestes,nestE);

					pokenest * nestF = malloc(sizeof(pokenest));
								nestF->simbolo= "¡";
								nestF->cantidad=2;
								/* agrego los poke a la lista */

								 list_add(pokenestes,nestF);

	free(nestA);
	free(nestB);
	free(nestC);
	free(nestD);
	free(nestE);
	free(nestF);

	return pokenestes;

}

t_list * datosHCEntrenadores(){

	/*defino mi lista de entrenadores*/

	t_list * entrenadores_en_mapa = list_create(); /*ok*/
	list_clean(entrenadores_en_mapa);

	/*defino un par de entrenadores*/
	entrenador * pepe = malloc(sizeof(entrenador));
	pepe->recurso_buscado = "@";
	pepe->simbolo ='(';
	pepe->bloqueado = 0;
	pepe->pokemones_atrapados[0]="%";
	pepe->pokemones_atrapados[1]="=";
	/* agrego los entrenadores a la lista */

	 list_add(entrenadores_en_mapa,pepe);

	entrenador * pepin = malloc(sizeof(entrenador));
	pepin->recurso_buscado = "&";
	pepin->simbolo =')';
	pepin->bloqueado = 0;
	pepin->pokemones_atrapados[0]="?";
	pepin->pokemones_atrapados[1]="¡";
	list_add(entrenadores_en_mapa,pepin);

	free(pepe);
	free(pepin);

	return entrenadores_en_mapa;

}




int main(){

	int existeInterbloqueo = 0;



	t_list* entrenadores = list_create();
	entrenadores = datosHCEntrenadores();

	t_list* pokenestes = list_create();

	pokenestes = datosHCPokenests();

	bool contiene(char chare, char chare2 ){
		return (chare == chare2);
	}


	bool esta_bloqueado(entrenador * ent){
		return (ent->bloqueado == 1);
	}
	bool no_esta_bloqueado(entrenador * ent){
		return (ent->bloqueado == 0);
	}

	t_list *filtrarBloqueados;
	filtrarBloqueados = list_filter(entrenadores, no_esta_bloqueado);

/*esto fue para ver que le llegan la cantidad correcta de entrenadores*/
	/*int nroElemenQ = filtrarBloqueados->elements_count;*/
  /*printf("valor es %d\n ", nroElemenQ);*/




if(list_size(filtrarBloqueados) != 0){
	if( list_size(filtrarBloqueados)>=2){

/*Armar las matrices
 * cantidad de filas
 */
		int filasEntrenadores = (filtrarBloqueados->elements_count);
		int iELLE = 0;

		iELLE = (filtrarBloqueados->elements_count)-1; /*InteracionesEnLaListaEntrenadores*/
		/* printf("valor es %d\n ", iELLE ); ok dio 1*/
		t_list *pokemones;


		int renglon;
		for(renglon=1;renglon<=iELLE;renglon++){

	/* entrenador * ent = * list_get(filtrarBloqueados, renglon);*/
	 /*agrego a la lisa el char del pkmn buscado por el entrenador*/
			char chare = ((entrenador*)list_get(filtrarBloqueados,renglon))->recurso_buscado;

	/* printf("ASCII value = %d, Character = %c\n", chare , chare );*/
	/*verifico que el char no esta en la lista de char antes de meter*/

			t_list * esta = list_filter(pokemones,contiene);

			printf("ASCII value = %d %c,\n", iELLE , chare );
			if(list_is_empty(esta)==0){
			list_add(pokemones,chare);
			}
			printf("NO HAGO \n ");
	 /*agrego a la lista los chars del array de pkmns encontrados por el entrenador*/
			int auxLargoArraypkmBuscados = sizeof(((entrenador*)list_get(filtrarBloqueados,renglon))->pokemones_atrapados);
			char pkmBusca[auxLargoArraypkmBuscados];

			if(auxLargoArraypkmBuscados !=0){
				memcpy(pkmBusca, ((entrenador*)list_get(filtrarBloqueados,renglon))->pokemones_atrapados, auxLargoArraypkmBuscados );
					int i;
					for(i=0;i!=auxLargoArraypkmBuscados-1;i++){
						list_clean(esta);
						t_list * esta = list_filter(pokemones,chare);
						if(list_is_empty(esta)==0){
						list_add(pokemones, pkmBusca[i]);
						}
					}
				}

		}


				/*	 int pkmnsEnBusqueda = (pokemones->elements_count);
					 printf("valor es %d\n ", pkmnsEnBusqueda );*/



 /* cantidad de columas de las matrices
  * los que tengan y busquen los entrenadores + 1(rotulos entrenadores)
  */
   int columnasPokemones = (pokemones->elements_count);
   int filasEntrenadores2 = (filtrarBloqueados->elements_count);
 	char arrayRotulosEntrenadores[filasEntrenadores2];
 	char arrayRotulosPokemones[columnasPokemones];

  int matrizSolicita[filasEntrenadores2][columnasPokemones];
  int matrizAsigna[filasEntrenadores2][columnasPokemones];

  	int arrayRecursos[columnasPokemones];
  	int arrayDisponibles[columnasPokemones];


/*RECIEN ACA TENGO LAS DIMENSIONES DE LAS MATRICES
 * RECORRO la lista filtrada de entrenadores PARA LLENARLAS
 * */

  	  	  /*LLENO EL ARRAY DE ENTRENADORES
  	  	   * y LLENO MATRIZ MSOLICITA y MAsigna
  	  	   * y Vector disponibles desde lista pokenestes
  	  	   * */
  	  	int renglon2;
  	  int columna;
  	  /*TODO llenar el array con el t list pokemones*/



  		for(renglon2=0;renglon2!=iELLE;renglon2++){
  			for (columna = 0; columna < columnasPokemones; columna++){
  				/*si simbolo ent del rengl == simbolo  buscado ==>  pongo 1 en
  				 * solicita[renglon][posDeSimbolo]

  				 * */
  				char simboloEnt = ((entrenador*)list_get(filtrarBloqueados,renglon2))->simbolo;
  				char simboloBusc = ((entrenador*)list_get(filtrarBloqueados,renglon2))->recurso_buscado;

  				/* ¿cual es la pos del simbolo?*/
  				int pos;
  				pos = list_find(pokemones,simboloBusc);

  				/*cargo el simbolo del entrenador en el array rotulo*/
  				arrayRotulosEntrenadores[renglon2]=((entrenador*)list_get(filtrarBloqueados,renglon2))->simbolo;
  				matrizSolicita[renglon2][pos]++;


   					/*los buscados de este entrenador*/
  				int largoArraypkmBuscados = sizeof(((entrenador*)list_get(filtrarBloqueados,renglon2))->pokemones_atrapados);
				char pkmBusca[largoArraypkmBuscados];

				if(largoArraypkmBuscados !=0){

  						memcpy(pkmBusca, ((entrenador*)list_get(filtrarBloqueados,renglon))->pokemones_atrapados, largoArraypkmBuscados );
  						int i;

  						for(i=0;i!=largoArraypkmBuscados-1;i++){
  								int pos2;
  								pos2 = list_find(pokemones,pkmBusca[i]);
  							  	matrizAsigna[renglon2][pos2]++;
  						}
  				}
  			 }
  		}

	  	  /*LLENO EL
	  	   * y Vector disponibles desde lista pokenestes
	  	   * */
  		for(renglon2=0;renglon2!=iELLE;renglon2++){
  			char simboloPKNST = ((pokenest*)list_get(pokenestes,renglon2))->simbolo;
  			int cantPKNST = ((pokenest*)list_get(pokenestes,renglon2))->cantidad;
  		int pos2;
  		pos2 = list_find(pokemones,simboloPKNST);
  		arrayDisponibles[pos2]=cantPKNST;


  		}



/*ACA ESTA EL ALGORITMMO DE INTERBLOQUEO POSTA*/
 /*1. Se marca cada proceso que tenga una fila de la matriz de Asignación
  *  completamente a cero.*/
	int filasEntrenadores3 = (filtrarBloqueados->elements_count);
	int arrayEntrenadoresMarcados[filasEntrenadores3];
	/*limpiamos*/
  	  	  int i;
  	  	  for(i=0;i!=filasEntrenadores3-1;i++){
  	  		arrayEntrenadoresMarcados[i]=0;
					}
  	  	  /*verificamos linea ==0*/
  	  	 int algunNoCero =0;

  	  	 for(i=0;i!=filasEntrenadores3-1;i++){
  	  		 matrizAsigna[filasEntrenadores3][columnasPokemones];
  	  		 int total =0;
  	  		 int i;
  	  		 for ( i = 0; i < columnasPokemones; i++ ) {
  	  			 total += matrizAsigna[filasEntrenadores3][ i ];
  	  		 }
  	  		 algunNoCero = total;
  	  		 if(algunNoCero>0){
  	  			 break;
  	  		 }
  	  		arrayEntrenadoresMarcados[filasEntrenadores3]=1;
  	  	 }





/*
2. Se inicia un vector temporal T asignándole el vector Disponibles.
*/

  	  int arrayTemporal[columnasPokemones];

  	  memcpy(arrayTemporal, arrayDisponibles, columnasPokemones);

  	  	 /*
3. Se busca un índice i tal que el proceso i no esté marcado actualmente (fila <>0) y la fila i-ésima de S sea
menor o igual que T. Es decir, S <= T k , para 1 £ k £ m. Si no se encuentra ninguna fila, el algo-
ritmo termina.*/

 		 for ( i = 0; i < filasEntrenadores3-1; i++ ) {
 			 if(arrayEntrenadoresMarcados[filasEntrenadores3]==0){
 				 int verifica;
 				int vectorTemporalRenglonMatrizSol[columnasPokemones];
 				int i2;
 				for (i2 = 0; i2 < columnasPokemones-1; i2++ ){
 					vectorTemporalRenglonMatrizSol[i2] = matrizSolicita[i][i2];

 				}




/* verifica (1 true, 0 false int esMenorArray(array que el array, posiciones*/


 			verifica = esMenorOIgualArray(vectorTemporalRenglonMatrizSol, arrayTemporal, columnasPokemones);
 			 if(verifica ==1){
 			  	  /*4. Si se encuentra una fila que lo cumpla, se marca el proceso i */
 				arrayEntrenadoresMarcados[i]=1;
 				/* y se suma la fila correspondiente de la matriz de asignación a T. Es decir,
 				 * se ejecuta T k = T k + A ik , para 1 £ k £ m. A continuación, se vuelve al tercer paso.*/

 							int vectorTemporalRenglonMatrizAsig[columnasPokemones];
 							int i3;
			 				for (i3 = 0; i3 < columnasPokemones-1; i3++ ){
 				 					vectorTemporalRenglonMatrizAsig[i3] = matrizAsigna[i][i3];
			 				}
			 				 int i4;
			 				for (i4 = 0; i4 < columnasPokemones-1; i4++ ){
			 				arrayTemporal[i4] = arrayTemporal[i4] + vectorTemporalRenglonMatrizAsig[i4];
			 				}


 			 }

 			 }
/*Si no se encuentra ninguna fila, el algoritmo termina*/

 		 }


 		 /*
Existe un interbloqueo si y sólo si hay procesos sin marcar al final del algoritmo. Cada proceso
sin marcar está en un interbloqueo.
  *
  */

 		existeInterbloqueo = estodoCeroArray(arrayEntrenadoresMarcados, columnasPokemones);

 		 /*
 * ACA TERMINA LA VERIFICACION DE INTERBLOQUEO*/
	}
				else{
				printf("HAY UN SOLO ELEMENTO EN LA LISTA");
				}
}
	else{
	printf("NO HAGO NADA LISTA VACIA ");
	}
printf("valor es %d\n ", existeInterbloqueo);
return existeInterbloqueo;

}


int esMenorOIgualArray(int array1[], int array2[], int posiciones){
	int i;
	int rta = 0;
	for (i = 0; i < posiciones-1; i++ ){
			if(array1[i]<=array2[i]){
				rta =1;
			}

	}
	return rta;
}


int estodoCeroArray(int array[], int posiciones){
	int i;
	int rta = 0;
	for (i = 0; i < posiciones-1; i++ ){
			if(array[i]==0){
				rta =1;
			}

	}
	return rta;
}
