#ifndef ENTRENADOR_H
#define ENTRENADOR_H
#define MAX_RECURSOS 20
 /*defino el tipo*/
	typedef struct {
		int x;
		int y;
	} posicion;

				typedef struct entrenador{
					char simbolo;
					posicion pos;
					int fd;
					int bloqueado;
					char recurso_buscado;
					int quantum_restante;
					int turno_srdf;
					char pokemones_atrapados[MAX_RECURSOS];

				} entrenador;

				typedef struct pokenest{
					char simbolo;
					posicion pos;
					int cantidad;
					char* tipo;
				} pokenest;

#endif
