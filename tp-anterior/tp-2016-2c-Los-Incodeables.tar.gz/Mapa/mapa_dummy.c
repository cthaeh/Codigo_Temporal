//CODIGOS
//900 ENT A MAPA - ENVIA SIMBOLO
//901 ENT A MAPA - PREGUNTA POS DE POKENEST
//910 ENT A MAPA - MUEVE X ARRIBA
//911 ENT A MAPA - MUEVE X ABAJO
//912 ENT A MAPA - MUEVE Y ARRIBA
//913 ENT A MAPA - MUEVE Y ABAJO
//920 ENT A MAPA - ATRAPAR POKEMON
//930 ENT A MAPA - FINALIZAR
//800 MAPA A ENT - TURNO CONSEDIDO
//801 MAPA A ENT - ENTREGA POSICION DE POKENEST
//810 MAPA A ENT - CONFIRMA CAPTURA POKEMON
//830 MAPA A ENT - FIN ACEPTADO
//899 MAPA A ENT - ENTRENADOR EN INTERBLOQUEO


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <commons/log.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <lbsockets/servidor.h>
#include <lbsockets/comunes.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <nivel.h>
#include <curses.h>
#include <tad_items.h>

#define MAX_RECURSOS 20

typedef struct {
	int x;
	int y;
} posicion;

typedef struct entrenadores{
	char simbolo;
	posicion pos;
	int fd;
	int bloqueado;
	char recurso_buscado;
	int quantum_restante;
	int turno_srdf;
	char pokemones_atrapados[MAX_RECURSOS];

} entrenadores_en_mapa;

typedef struct pokenest{
	char simbolo;
	posicion pos;
	int cantidad;
	char* tipo;
} pokenest;

typedef struct {
	char* ip;
	int puerto;
	int batalla;
	int retardo;
	char* algoritmo;
	int tiempo_interbloqueo;
	int quantum;
	t_list* pokenests;
} mapa;

typedef struct {
	mapa map;
	int socket;
	t_list* it;
} cliente;

void inicializarMapa(int*, int*, t_list**);
void sumarRecurso(t_list* items, char id);
bool encontrar_pokenest(pokenest* poke);
bool encontrar_entrenador(entrenadores_en_mapa* ent);
bool esta_bloqueado(entrenadores_en_mapa* ent);
void inicializar_pokemones_atrapados(char * rec);
int indice_libre(char * rec);
void* planificar(mapa* map);
void* entrenar (cliente* cli);
void recargar(int nada);
bool no_esta_bloqueado(entrenadores_en_mapa* ent);
mapa* cargarConfiguracion(char* mapa,char* dirPokeDex);
entrenadores_en_mapa * RoundRobin ();
entrenadores_en_mapa * SRDF(t_list* pokenests);

t_list* entrenadores;
char pokenest_buscada;
int fd_buscado;
int quantum_mapa;
mapa mapa_aux;
char* path_global;

pthread_mutex_t mutex_entrenadores = PTHREAD_MUTEX_INITIALIZER;

int main(int argc, char* argv[]){

	int socketServidor;				 /* Descriptor del socket servidor */
	int socketCliente[MAX_CLIENTES]; /* Descriptores de sockets con clientes */
	int numeroClientes = 0;			 /* Número clientes conectados */
	fd_set descriptoresLectura;		 /* Descriptores de interes para select() */
	int maximo;						 /* Número de descriptor más grande */
	int i;							 /* Para bubles */
	size_t longitudMensaje;
	int p = 0, q = 0;
	t_list* items = list_create();
	entrenadores = list_create();
	int retardo = 100000;
	pthread_t planificador;
	pthread_t entrenamiento;

	char* nombreMapa = argv[1];
	char* mntPokeDex = argv[2];

	signal (SIGUSR2, recargar);

	mapa_aux = *(cargarConfiguracion(nombreMapa, mntPokeDex));
	quantum_mapa = mapa_aux.quantum;
	mapa_aux.retardo = mapa_aux.retardo*500;

	pokenest poke_aux;
	int indice = 0;

	while(list_get(mapa_aux.pokenests, indice) != NULL){
		poke_aux = *((pokenest*)list_get(mapa_aux.pokenests, indice));
		CrearCaja(items, poke_aux.simbolo, poke_aux.pos.x, poke_aux.pos.y, poke_aux.cantidad);
		indice++;
	}

	//Inicializo la interfaz grafica del Mapa
	inicializarMapa(&p, &q, &items);

	entrenadores_en_mapa aux_entrenador;

	pthread_create(&planificador, NULL, (void*) planificar, &mapa_aux);


	/* Se abre el socket servidor, avisando por pantalla y saliendo si hay
	 * algún problema */
	socketServidor = Abre_Socket_Inet(mapa_aux.puerto);
	if (socketServidor == -1)
	{
		perror ("Error al abrir servidor");
		exit (-1);
	}



	/* Bucle infinito.
	 * Se atiende a si hay más clientes para conectar y a los mensajes enviados
	 * por los clientes ya conectados */
	while (1)
	{
		/* Cuando un cliente cierre la conexión, se pondrá un -1 en su descriptor
		 * de socket dentro del array socketCliente. La función compactaClaves()
		 * eliminará dichos -1 de la tabla, haciéndola más pequeña.
		 *
		 * Se eliminan TODOs los clientes que hayan cerrado la conexión */
		compactaClaves (socketCliente, &numeroClientes);

		/* Se inicializa descriptoresLectura */
		FD_ZERO (&descriptoresLectura);

		/* Se añade para select() el socket servidor */
		FD_SET (socketServidor, &descriptoresLectura);

		/* Se añaden para select() los sockets con los clientes ya conectados */
		for (i=0; i<numeroClientes; i++)
			FD_SET (socketCliente[i], &descriptoresLectura);

		/* Se el valor del descriptor más grande. Si no hay ningún cliente,
		 * devolverá 0 */
		maximo = dameMaximo (socketCliente, numeroClientes);

		if (maximo < socketServidor)
			maximo = socketServidor;

		/* Espera indefinida hasta que alguno de los descriptores tenga algo
		 * que decir: un nuevo cliente o un cliente ya conectado que envía un
		 * mensaje */
		select (maximo + 1, &descriptoresLectura, NULL, NULL, NULL);

		/* Se comprueba si algún cliente nuevo desea conectarse y se le
		 * admite */
		if (FD_ISSET (socketServidor, &descriptoresLectura)) {
			int socket_cli = nuevoCliente(socketServidor, socketCliente, &maximo);

			cliente* cli = malloc(sizeof(cliente));
			cli->socket = socket_cli;
			cli->map = mapa_aux;
			cli->it = list_create();
			cli->it = items;

			pthread_create(&entrenamiento, NULL, (void*) entrenar, cli);
			//nuevoCliente (socketServidor, socketCliente, &numeroClientes);
		}
	}
}

void recargar(int nada){
	printf("Manejo la señal \n");

	t_config* metadata = config_create(path_global);

	mapa_aux.algoritmo = config_get_string_value(metadata, "algoritmo");
	mapa_aux.quantum = config_get_int_value(metadata,"quantum");
	quantum_mapa = mapa_aux.quantum;
	mapa_aux.tiempo_interbloqueo = config_get_int_value(metadata,"TiempoChequeoDeadlock");
	mapa_aux.retardo = config_get_int_value(metadata,"retardo");

}

void* entrenar (cliente* cli){
	int retardo = 100000;
	size_t longitudMensaje;
	entrenadores_en_mapa aux_entrenador;
	entrenadores_en_mapa* aux_entrenador2 = malloc(sizeof(entrenadores_en_mapa));
	t_list* items = list_create();
	items = cli->it;
	pokenest poke_aux;
	pokenest* poke_aux2 = malloc(sizeof(pokenest));
	mapa mapa_aux = cli->map;
	int indice = 0;


	while(1){
		char* mensaje2 = string_new();
		int flag = leeSocket(cli->socket, &longitudMensaje, sizeof(size_t));
		char mensaje[longitudMensaje];
		read(cli->socket, &mensaje, sizeof(mensaje));

		if(flag > 0){
			char* codigo = string_new();
			char* simb = string_new();
			char* simb_pokenest = string_new();;


			switch(atoi(strtok(mensaje, ";"))){
			case 900:

				simb = strtok(NULL, ";");
				simb_pokenest = strtok(NULL, ";");

				aux_entrenador.pos.x = 0;
				aux_entrenador.pos.y = 0;
				aux_entrenador.bloqueado = 0;
				aux_entrenador.quantum_restante = 0;
				aux_entrenador.turno_srdf = 0;
				aux_entrenador.fd = cli->socket;
				aux_entrenador.simbolo = *simb;
				aux_entrenador.recurso_buscado = *simb_pokenest;

				inicializar_pokemones_atrapados(aux_entrenador.pokemones_atrapados);

				pthread_mutex_lock(&mutex_entrenadores);
				list_add(entrenadores, &aux_entrenador);
				pthread_mutex_unlock(&mutex_entrenadores);

				CrearPersonaje(items,aux_entrenador.simbolo,aux_entrenador.pos.x,aux_entrenador.pos.y);
				nivel_gui_dibujar(items, "Char* Mander");
				break;

			case 901:
				simb_pokenest = strtok(NULL, ";");
				pokenest_buscada = *simb_pokenest;
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));

				aux_entrenador.recurso_buscado = *simb_pokenest;

				poke_aux = *((pokenest*)(list_find(mapa_aux.pokenests,encontrar_pokenest)));
				string_append(&mensaje2, "801;");
				string_append(&mensaje2, string_itoa(poke_aux.pos.x));
				string_append(&mensaje2, ";");
				string_append(&mensaje2, string_itoa(poke_aux.pos.y));
				string_append(&mensaje2, ";");

				size_t longitudMensaje = strlen(mensaje2)+1;
				write(cli->socket,mensaje2,sizeof(char[longitudMensaje]));
				break;

			case 910:
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));

				pthread_mutex_lock(&mutex_entrenadores);
				aux_entrenador.pos.x ++;
				pthread_mutex_unlock(&mutex_entrenadores);

				MoverPersonaje(items,aux_entrenador.simbolo,aux_entrenador.pos.x,aux_entrenador.pos.y);
				break;

			case 911:
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));

				pthread_mutex_lock(&mutex_entrenadores);
				aux_entrenador.pos.x --;
				pthread_mutex_unlock(&mutex_entrenadores);

				MoverPersonaje(items,aux_entrenador.simbolo,aux_entrenador.pos.x,aux_entrenador.pos.y);
				break;

			case 912:
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));

				pthread_mutex_lock(&mutex_entrenadores);
				aux_entrenador.pos.y ++;
				pthread_mutex_unlock(&mutex_entrenadores);

				MoverPersonaje(items,aux_entrenador.simbolo,aux_entrenador.pos.x,aux_entrenador.pos.y);
				break;

			case 913:
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));

				pthread_mutex_lock(&mutex_entrenadores);
				aux_entrenador.pos.y --;
				pthread_mutex_unlock(&mutex_entrenadores);

				MoverPersonaje(items,aux_entrenador.simbolo,aux_entrenador.pos.x,aux_entrenador.pos.y);
				break;

			case 920:

				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));
				aux_entrenador.turno_srdf = 0;
				simb_pokenest = strtok(NULL, ";");
				pokenest_buscada = *simb_pokenest;
				poke_aux2 = ((pokenest*)(list_find(mapa_aux.pokenests,encontrar_pokenest)));

				if(poke_aux2->cantidad != 0){
					poke_aux2->cantidad--;
					indice = indice_libre(aux_entrenador.pokemones_atrapados);

					if(indice != -1){
						pthread_mutex_lock(&mutex_entrenadores);
						aux_entrenador.pokemones_atrapados[indice] = *simb_pokenest;
						pthread_mutex_unlock(&mutex_entrenadores);
					}

					restarRecurso(items,*simb_pokenest);

					string_append(&mensaje2, "810");

					longitudMensaje = strlen(mensaje2)+1;

					write(cli->socket,mensaje2,sizeof(char[longitudMensaje]));

				}else{

					pthread_mutex_lock(&mutex_entrenadores);
					aux_entrenador.bloqueado = 1;
					aux_entrenador.turno_srdf = 0;
					aux_entrenador.quantum_restante = 0;
					pthread_mutex_unlock(&mutex_entrenadores);
				}
				break;

			case 930:
				fd_buscado = cli->socket;
				aux_entrenador = *((entrenadores_en_mapa*)(list_find(entrenadores,encontrar_entrenador)));
				t_list* entrenadores_bloqueados = list_create();
				simb = strtok(NULL, ";");

				indice = indice_libre(aux_entrenador.pokemones_atrapados);
				indice--;

				while(indice != -1){
					int indice_entrenadores = 0;
					int encontrado = 0;
					int indice_pokemon_a_incertar = 0;
					pokenest_buscada = aux_entrenador.pokemones_atrapados[indice];
					poke_aux2 = ((pokenest*)(list_find(mapa_aux.pokenests,encontrar_pokenest)));

					entrenadores_bloqueados = list_filter(entrenadores, esta_bloqueado);

					if(list_is_empty(entrenadores_bloqueados)){
						encontrado = 0;
					}
					else{
						while(((entrenadores_en_mapa*)list_get(entrenadores_bloqueados,indice_entrenadores)) != NULL){
							if(encontrado == 0){
								aux_entrenador2 = ((entrenadores_en_mapa*)list_get(entrenadores_bloqueados,indice_entrenadores));
								if(aux_entrenador2->recurso_buscado == poke_aux2->simbolo){
									string_append(&mensaje2, "810");

									indice_pokemon_a_incertar = indice_libre(aux_entrenador2->pokemones_atrapados);
									if(indice != -1){
										pthread_mutex_lock(&mutex_entrenadores);
										aux_entrenador2->pokemones_atrapados[indice_pokemon_a_incertar] = aux_entrenador.pokemones_atrapados[indice];
										pthread_mutex_unlock(&mutex_entrenadores);
									}

									longitudMensaje = strlen(mensaje2)+1;

									aux_entrenador2->bloqueado = 0;

									write(aux_entrenador2->fd,mensaje2,sizeof(char[longitudMensaje]));

									encontrado = 1;
								}
							}
							indice_entrenadores ++;
						}
					}


					if(encontrado == 0){

						poke_aux2->cantidad++;
						sumarRecurso(items, aux_entrenador.pokemones_atrapados[indice]);
						aux_entrenador.pokemones_atrapados[indice] = ' ';
					}

					indice--;

				}

				pthread_mutex_lock(&mutex_entrenadores);
				list_remove_by_condition(entrenadores, encontrar_entrenador);
				pthread_mutex_unlock(&mutex_entrenadores);
				longitudMensaje = strlen("830")+1;
				write(cli->socket,"830",sizeof(char[longitudMensaje]));
				BorrarItem(items, *simb);
				break;
			}

			usleep(retardo);
			nivel_gui_dibujar(items, "Char* Mander");
		}
	}
}

void* planificar(mapa* map){
	int longitudMensaje;
	entrenadores_en_mapa* aux_entrenador = malloc(sizeof(entrenadores_en_mapa));
	while(1){
		usleep(200000);

		t_list* entrenadores_activos = list_create();
		entrenadores_activos = list_filter(entrenadores, no_esta_bloqueado);

		if(!list_is_empty(entrenadores_activos)){
			char* algoritmo = string_new();
			algoritmo = mapa_aux.algoritmo;

			if(algoritmo[0] == 'R'){

				aux_entrenador = RoundRobin();

				if(aux_entrenador->quantum_restante > 0){
					aux_entrenador->quantum_restante --;
				}else{
					aux_entrenador->quantum_restante = quantum_mapa;
					aux_entrenador->quantum_restante --;
				}
				longitudMensaje = strlen("800")+1;

				write(aux_entrenador->fd,"800",sizeof(char[longitudMensaje]));
				int i = 0;
				int indice_ent_buscado = 0;
				for(i= 0; i <list_size(entrenadores); i++){
					if (aux_entrenador->simbolo == ((entrenadores_en_mapa*)list_get(entrenadores,i))->simbolo){
						indice_ent_buscado = i;
						break;
					}
				}

				if(aux_entrenador->quantum_restante == 0){
					pthread_mutex_lock(&mutex_entrenadores);
					list_remove(entrenadores, indice_ent_buscado);
					list_add(entrenadores, aux_entrenador);
					pthread_mutex_unlock(&mutex_entrenadores);
				}
			}else{
				aux_entrenador = SRDF(mapa_aux.pokenests);

				longitudMensaje = strlen("800")+1;
				write(aux_entrenador->fd,"800",sizeof(char[longitudMensaje]));
			}
		}
	}
}

mapa* cargarConfiguracion(char* NombreMapa,char* dirPokeDex){
	char* path = string_new();
	path_global = string_new();
	char* path_nest = string_new();


	string_append(&path,dirPokeDex);
	string_append(&path,"/Mapas/");
	string_append(&path,NombreMapa);
	string_append(&path,"/metadata");

	string_append(&path_global,dirPokeDex);
	string_append(&path_global,"/Mapas/");
	string_append(&path_global,NombreMapa);
	string_append(&path_global,"/metadata");

	string_append(&path_nest,dirPokeDex);
	string_append(&path_nest,"/Mapas/");
	string_append(&path_nest,NombreMapa);
	string_append(&path_nest,"/PokeNests");

	DIR *dir;
	struct dirent *entrada;
	struct stat entrada_stat;

	DIR *dir2;
	struct dirent *entrada2;
	int instancias;

	mapa* map = malloc(sizeof(mapa));

	t_config* metadata = config_create(path);

	map->algoritmo = config_get_string_value(metadata, "algoritmo");
	map->batalla = config_get_int_value(metadata,"Batalla");
	map->quantum = config_get_int_value(metadata,"quantum");
	map->tiempo_interbloqueo = config_get_int_value(metadata,"TiempoChequeoDeadlock");
	map->ip = config_get_string_value(metadata, "IP");
	map->puerto = config_get_int_value(metadata,"Puerto");
	map->retardo = config_get_int_value(metadata,"retardo");
	map->pokenests = list_create();

	dir = opendir(path_nest);
	entrada=readdir(dir);
	while (entrada != NULL) {
		instancias = 0;
		if(entrada->d_name != "."){
		char* path2 = string_new();
		char* path_pokemons = string_new();

		string_append(&path2,dirPokeDex);
		string_append(&path2,"/Mapas/");
		string_append(&path2,NombreMapa);
		string_append(&path2,"/PokeNests/");
		string_append(&path2,entrada->d_name);
		string_append(&path2,"/metadata");

		string_append(&path_pokemons,dirPokeDex);
		string_append(&path_pokemons,"/Mapas/");
		string_append(&path_pokemons,NombreMapa);
		string_append(&path_pokemons,"/PokeNests/");
		string_append(&path_pokemons,entrada->d_name);

		stat(entrada->d_name, &entrada_stat);

		if (S_ISDIR(entrada_stat.st_mode) ) {

		}else{
			metadata = config_create(path2);
			pokenest* poke_aux = malloc(sizeof(pokenest));
			poke_aux->simbolo = *(config_get_string_value(metadata, "Identificador"));
			poke_aux->tipo = config_get_string_value(metadata, "Tipo");
			char* pos = config_get_string_value(metadata, "Posicion");

			poke_aux->pos.x = atoi(strtok(pos, ";"));
			poke_aux->pos.y = atoi(strtok(NULL, ""));;

			dir2 = opendir (path_pokemons);

			entrada2 = readdir (dir2);
			while (entrada2 != NULL){
				if ( (strcmp(entrada2->d_name, ".")!=0) && (strcmp(entrada2->d_name, "..")!=0) ){
					instancias++;
			    }

				entrada2 = readdir (dir2);
			}

			poke_aux->cantidad = instancias-1;

			list_add(map->pokenests, poke_aux);

		}
		entrada = readdir(dir);
		}
	}
	return map;
}

void inicializarMapa(int *p, int *q, t_list** items){

	int rows, cols;

	nivel_gui_inicializar();

	nivel_gui_get_area_nivel(&rows, &cols);

	*p = cols;
	*q = rows;

	nivel_gui_dibujar(*items, "Char* Mander");
}

ITEM_NIVEL* _search_item_by_id(t_list* items, char id) {
	bool _search_by_id(ITEM_NIVEL* item) {
        return item->id == id;
    }
    return list_find(items, (void*) _search_by_id);
}

void sumarRecurso(t_list* items, char id) {
    ITEM_NIVEL* item = _search_item_by_id(items, id);

    if (item != NULL) {
        item->quantity += 1;
    }
}

bool encontrar_pokenest(pokenest* poke){

	return poke->simbolo == pokenest_buscada;

}

bool encontrar_entrenador(entrenadores_en_mapa* ent){

	return ent->fd == fd_buscado;

}

void inicializar_pokemones_atrapados(char * rec){
	int i;
	for(i = 0; i < MAX_RECURSOS; i++){
		rec[i] = ' ';
	}
}

int indice_libre(char * rec){
	int i;
	for(i = 0; i < MAX_RECURSOS; i++){
		if(rec[i] == ' '){
			return i;
		}
	}

	return -1;
}

bool no_esta_bloqueado(entrenadores_en_mapa* ent){
	return (ent->bloqueado == 0);
}

bool esta_bloqueado(entrenadores_en_mapa* ent){
	return (ent->bloqueado != 0);
}

entrenadores_en_mapa * RoundRobin (){
	t_list* entrenadores_activos = list_create();
	entrenadores_activos = list_filter(entrenadores, no_esta_bloqueado);

	int _soy_0(entrenadores_en_mapa * p ) {
		return p->quantum_restante == 0;
	};

	int _soy_no_0(entrenadores_en_mapa * p ) {
		return p->quantum_restante != 0;
	};

	if(list_all_satisfy(entrenadores_activos, _soy_0)){
		return list_get(entrenadores_activos,0);
	}else{
		return (entrenadores_en_mapa*) list_find(entrenadores_activos,(_soy_no_0));
	}
}

int comparacionModulo(int a, int b){
	int rdo = (a-b);
	if(rdo<0){
		return (rdo*(-1));
	}
	else{
		return rdo;
	}
};

int distancia (posicion a, posicion b){
	int x = comparacionModulo(a.x, b.x);
	int y = comparacionModulo(a.y, b.y);
	return (x + y);
}

entrenadores_en_mapa * SRDF(t_list* pokenests){

	bool sinturnoSRDF(entrenadores_en_mapa * p) {
			return p->turno_srdf == 0;
													};
	bool conturnoSRDF(entrenadores_en_mapa * p) {
			return p->turno_srdf != 0;
													};

	int menor = 1000;
	int indice_ent = 0;
	char simbolo_menor = ' ';

	if(list_all_satisfy(entrenadores, sinturnoSRDF)){
		/*todos sdrf = 0, => nadie esta ejecutando
		buscar dist mas chica de todos y devolverlo
		busqueda de menor con while, luedo buscar el char del menor*/

			entrenadores_en_mapa * currentEntrenador = malloc(sizeof(entrenadores_en_mapa));

			while(((entrenadores_en_mapa *)list_get(entrenadores, indice_ent)) != NULL){

				currentEntrenador = ((entrenadores_en_mapa *)list_get(entrenadores,indice_ent));
				char pokemon_buscado = currentEntrenador->recurso_buscado;

				int _soy_esePKMn(pokenest * p ) {
					return p->simbolo == pokemon_buscado;
				};

				pokenest * pmnBuscado  = malloc(sizeof(pokenest));
				pmnBuscado = ((pokenest*) list_find(pokenests ,(_soy_esePKMn)));

				int currentDistancia = distancia(pmnBuscado->pos, currentEntrenador->pos);

				if(currentDistancia < menor){
					menor = currentDistancia;
					simbolo_menor = currentEntrenador->simbolo;
				}

				indice_ent++;
			}

			int _soy_eseEntrenador(entrenadores_en_mapa * p ) {
								return p->simbolo == simbolo_menor;
							};
			entrenadores_en_mapa * entADevolver = malloc(sizeof(entrenadores_en_mapa));
			entADevolver = ((entrenadores_en_mapa *)list_find(entrenadores,(_soy_eseEntrenador)));
			entADevolver->turno_srdf = 1;
			return entADevolver;
	}
	else {/*retorna quien si tienen turno ==1*/

		return  ((entrenadores_en_mapa *)list_find(entrenadores,(conturnoSRDF)));

	}
}
