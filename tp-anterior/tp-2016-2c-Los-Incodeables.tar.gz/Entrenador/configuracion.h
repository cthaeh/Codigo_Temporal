#ifndef CONFIGURACION_H_
#define CONFIGURACION_H_

#include <commons/config.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <commons/log.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_MAPAS 10

typedef struct {
	int x;
	int y;
} posicion;

typedef struct recurso{
	char pokemon;
	posicion pokepos;
	int atrapado;
} recursos;

typedef struct{
	char* nombre;
	char** objetivos;
	char* ip;
	uint puerto;
	int finalizado;
	t_list* lista_recursos;
} Mapa;

typedef struct{
	char* nombre;
	char* simbolo;
	t_list* mapas;
	uint vidas;
	uint reintentos;
	posicion pos;
} Entrenador;


Entrenador* cargarConfiguracion(char*,char*,t_log*);
Mapa* crearMapa(char*,char*, t_config*, t_log*);
void _list_elements(Mapa *);


#endif /* CONFIGURACION_H_ */

