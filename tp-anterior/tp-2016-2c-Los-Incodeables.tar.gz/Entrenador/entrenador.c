//CODIGOS
//900 ENT A MAPA - ENVIA SIMBOLO
//901 ENT A MAPA - PREGUNTA POS DE POKENEST
//910 ENT A MAPA - MUEVE X ARRIBA
//911 ENT A MAPA - MUEVE X ABAJO
//912 ENT A MAPA - MUEVE Y ARRIBA
//913 ENT A MAPA - MUEVE Y ABAJO
//920 ENT A MAPA - ATRAPAR POKEMON
//930 ENT A MAPA - FINALIZAR
//800 MAPA A ENT - TURNO CONSEDIDO
//801 MAPA A ENT - ENTREGA POSICION DE POKENEST
//810 MAPA A ENT - CONFIRMA CAPTURA POKEMON
//830 MAPA A ENT - FIN ACEPTADO
//899 MAPA A ENT - ENTRENADOR EN INTERBLOQUEO

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <commons/log.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <lbsockets/cliente.h>
#include <lbsockets/comunes.h>
#include <sys/socket.h>

typedef struct {
	int x;
	int y;
} posicion;

typedef struct recurso{
	char pokemon;
	posicion pokepos;
	int atrapado;
} recursos;

typedef struct mapa{
	char* nombre;
	char* ip;
	int puerto;
	int finalizado;
	t_list* lista_recursos;
} mapas;

typedef struct {
	char* nombre;
	char simbolo;
	int vidas;
	int reintentos;
	t_list* viaje;
	posicion pos;
} entrenadores;

mapas* cargarDatosMapa(char* nomMapa, char* dirPokeDex, t_log* logger);
entrenadores* cargarConfiguracionE(char* entrenador,char* dirPokeDex,t_log* logger);
void copiarMetadataPoke(char* nombreEntrenador,mapas* mapaActual,char* pokemon,char* dirPokeDex);
void copiarMedallaMapa(char* nombreEntrenador,mapas* mapaActual,char* mntPokeDex);
void darVida(int a);
void quitarVida(int a);

entrenadores entrenador;
int reinicio;
int muerte;

int main(int argc, char* argv[]){

	t_log* logger = log_create("entrenador.log","CHARMANDER",true, LOG_LEVEL_DEBUG);

	char* nombreEntrenador = argv[1];
	char* mntPokeDex = argv[2];
	reinicio = 2;
	muerte = 0;
	signal(SIGUSR1, darVida);
	signal(SIGTERM, quitarVida);

	entrenador = *(cargarConfiguracionE(nombreEntrenador,mntPokeDex,logger));

	printf("VIDA = %d, REITENTOS = %d, NOMBRE = %s \n", entrenador.vidas, entrenador.reintentos, entrenador.nombre);

	recursos rec_aux;

	int turno_concedido = 0;
	int socket_server;
	int error;
	int salir = 0;
	char mensaje[1000] = "";


	int indice_mapa = 0;

	mapas* mapaActual = (mapas*)(list_get(entrenador.viaje,indice_mapa));

	while(mapaActual != NULL){
		printf("\n");
		printf("Entrando en Mapa %s \n", mapaActual->nombre);
		printf("IP = %s PUERTO = %d \n", mapaActual->ip, mapaActual->puerto);
		socket_server = Abre_Conexion_Inet(mapaActual->ip,mapaActual->puerto);

		rec_aux = *((recursos*) list_get(((mapas*)(list_get(entrenador.viaje,0)))->lista_recursos,0));

		mensaje[0] = '9';
		mensaje[1] = '0';
		mensaje[2] = '0';
		mensaje[3] = ';';
		mensaje[4] = entrenador.simbolo;
		mensaje[5] = ';';
		mensaje[6] = rec_aux.pokemon;
		mensaje[7] = ';';
		size_t longitudMensaje = strlen(mensaje)+1;

		escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
		escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

		int indice_rec= 0;

		while(((recursos*) list_get(mapaActual->lista_recursos,indice_rec)) != NULL){

			rec_aux = *((recursos*) list_get(mapaActual->lista_recursos,indice_rec));
			printf("EL POKEMON BUSCADO ES = %c \n", rec_aux.pokemon);
			char* codigo;

			while(turno_concedido != 1){

				read(socket_server, &mensaje, sizeof(mensaje));

				codigo = strtok(mensaje, ";");

				if(atoi(codigo) == 800){
					turno_concedido = 1;
				}
			}

			turno_concedido = 0;

			mensaje[0] = '9';
			mensaje[1] = '0';
			mensaje[2] = '1';
			mensaje[3] = ';';
			mensaje[4] = rec_aux.pokemon;
			mensaje[5] = ';';
			longitudMensaje = strlen(mensaje)+1;
			escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
			escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

			char* posx;
			char* posy;



			salir = 0;
			while(salir == 0){
				read(socket_server, &mensaje, sizeof(mensaje));
				codigo = strtok(mensaje, ";");
				if(atoi(codigo) == 801){
					posx = strtok(NULL, ";");
					posy = strtok(NULL, ";");
					rec_aux.pokepos.x = atoi(posx);
					rec_aux.pokepos.y = atoi(posy);
					salir = 1;
				}
			}



			salir = 0;
			int toca_moverse_en_x = 0;


			while(entrenador.pos.x != rec_aux.pokepos.x ||
					entrenador.pos.y != rec_aux.pokepos.y){

				while(turno_concedido != 1){
					read(socket_server, &mensaje, sizeof(mensaje));
					codigo = strtok(mensaje, ";");
					if(atoi(codigo) == 800){
						turno_concedido = 1;
					}
				}

				turno_concedido = 0;

				if(entrenador.pos.x != rec_aux.pokepos.x){
					if(toca_moverse_en_x == 0 || entrenador.pos.y == rec_aux.pokepos.y ){
						if(entrenador.pos.x < rec_aux.pokepos.x){
							entrenador.pos.x++;
							toca_moverse_en_x = 1;
							mensaje[0] = '9';
							mensaje[1] = '1';
							mensaje[2] = '0';
							mensaje[3] = ';';
							longitudMensaje = strlen(mensaje)+1;
							escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
							escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
						}else{
							entrenador.pos.x--;
							toca_moverse_en_x = 1;
							mensaje[0] = '9';
							mensaje[1] = '1';
							mensaje[2] = '1';
							mensaje[3] = ';';
							longitudMensaje = strlen(mensaje)+1;
							escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
							escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
						}
					}else{
						if(entrenador.pos.y != rec_aux.pokepos.y){
						if(entrenador.pos.y < rec_aux.pokepos.y){
							entrenador.pos.y++;
							toca_moverse_en_x = 0;
							mensaje[0] = '9';
							mensaje[1] = '1';
							mensaje[2] = '2';
							mensaje[3] = ';';
							longitudMensaje = strlen(mensaje)+1;
							escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
							escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
						}else{
							entrenador.pos.y--;
							toca_moverse_en_x = 0;
							mensaje[0] = '9';
							mensaje[1] = '1';
							mensaje[2] = '3';
							mensaje[3] = ';';
							longitudMensaje = strlen(mensaje)+1;
							escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
							escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
						}
						}else{
							toca_moverse_en_x = 0;
						}
					}
				}else{
					if(entrenador.pos.y < rec_aux.pokepos.y){
						entrenador.pos.y++;
						toca_moverse_en_x = 0;
						mensaje[0] = '9';
						mensaje[1] = '1';
						mensaje[2] = '2';
						mensaje[3] = ';';
						longitudMensaje = strlen(mensaje)+1;
						escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
						escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
					}else{
						entrenador.pos.y--;
						toca_moverse_en_x = 0;
						mensaje[0] = '9';
						mensaje[1] = '1';
						mensaje[2] = '3';
						mensaje[3] = ';';
						longitudMensaje = strlen(mensaje)+1;
						escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
						escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));
					}
				}
			}

			while(turno_concedido != 1){
				read(socket_server, &mensaje, sizeof(mensaje));
				codigo = strtok(mensaje, ";");
				if(atoi(codigo) == 800){
					turno_concedido = 1;
				}
			}

			mensaje[0] = '9';
			mensaje[1] = '2';
			mensaje[2] = '0';
			mensaje[3] = ';';
			mensaje[4] = rec_aux.pokemon;
			mensaje[5] = ';';
			longitudMensaje = strlen(mensaje)+1;
			escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
			escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

			while(salir == 0){
				read(socket_server, &mensaje, sizeof(mensaje));

				codigo = strtok(mensaje, ";");

				if(atoi(codigo) == 810){
					rec_aux.atrapado = 1;
					indice_rec++;
					salir = 1;
				}
			}

			salir = 0;
		}

		mensaje[0] = '9';
		mensaje[1] = '3';
		mensaje[2] = '0';
		mensaje[3] = ';';
		mensaje[4] = entrenador.simbolo;
		mensaje[5] = ';';
		longitudMensaje = strlen(mensaje)+1;
		escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
		escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

		while(salir == 0){
			read(socket_server, &mensaje, sizeof(mensaje));
			char* codigo = strtok(mensaje, ";");

			if(atoi(codigo) == 830){
				salir = 1;
			}
		}
		shutdown(socket_server, 2);
		entrenador.pos.x = 0;
		entrenador.pos.y = 0;

		indice_mapa++;
		mapaActual = (mapas*)list_get(entrenador.viaje,indice_mapa);
	}
	return EXIT_SUCCESS;
}

void darVida(int a){
	entrenador.vidas++;

	printf("He ganado una vida. Ahora tengo %d \n", entrenador.vidas);

}

void quitarVida(int a){
	if(entrenador.vidas == 0){
		printf("No tengo más vidas, soy un Zombie \n");
		//TODO aqui debe preguntar por reinicio
	}else{
		entrenador.vidas--;

		printf("Me has quitado una vida. Ahora tengo %d \n", entrenador.vidas);

		if(entrenador.vidas == 1){
			printf("Me queda una sola vida, tengo cuidado con lo que haces \n");

		}

		if(entrenador.vidas == 0){
			muerte = 0;
			char* cadena = string_new();

			printf("Sus vidas son Cero, Si quiere reiniciar ingrese: Y \n");
			fgets(cadena, 10, stdin);
			if(cadena[0] == 'Y' || cadena[0] == 'y'){
				reinicio = 1;
			}else{
				reinicio = 0;
			}
		}

	}
}

entrenadores* cargarConfiguracionE(char* entrenador,char* dirPokeDex,t_log* logger) {

	char* path = string_new();
	string_append(&path,dirPokeDex);
	string_append(&path,"/Entrenadores/");
	string_append(&path,entrenador);
	string_append(&path,"/metadata");

	entrenadores* ent = malloc(sizeof(entrenadores));
	t_config* metadata = config_create(path);

	if(path==NULL){
		log_error(logger,"No se encontró el archivo de configuración.");
		exit (EXIT_FAILURE);
	}

	char** mapasAux = config_get_array_value(metadata,"hojaDeViaje");

	ent->nombre = config_get_string_value(metadata, "nombre");
	ent->simbolo = *(config_get_string_value(metadata,"simbolo"));
	ent->vidas = config_get_int_value(metadata,"vidas");
	ent->reintentos = config_get_int_value(metadata,"reintentos");
	ent->pos.x = 0;
	ent->pos.y = 0;
	ent->viaje = list_create();


	int i = 0;
	while (mapasAux[i] != NULL) {

		mapas* mapa_aux = cargarDatosMapa(mapasAux[i], dirPokeDex, logger);

		char* objetivos = string_new();

		string_append(&objetivos, "obj[");
		string_append(&objetivos, mapasAux[i]);
		string_append(&objetivos, "]");

		char** obj = config_get_array_value(metadata, objetivos);

		int j = 0;
		while(obj[j] != NULL){
			recursos* recu_aux = malloc(sizeof(recursos));
			recu_aux->atrapado = 0;
			recu_aux->pokepos.x = 100;
			recu_aux->pokepos.y = 100;
			recu_aux->pokemon = *(obj[j]);

			list_add(mapa_aux->lista_recursos, recu_aux);
			j++;
		}

		list_add(ent->viaje, mapa_aux);
		i++;
	}

	return ent;

}

mapas* cargarDatosMapa(char* nomMapa, char* dirPokeDex, t_log* logger){
	char* path = string_new();
	string_append(&path,dirPokeDex);
	string_append(&path,"/Mapas/");
	string_append(&path,nomMapa);
	string_append(&path,"/metadata");
	t_config* metadataMapa = config_create(path);

	if(path==NULL){
		log_error(logger,"No se encontró el archivo de configuración del Mapa ");
		log_error(logger, nomMapa);
		exit (EXIT_FAILURE);
	}

	mapas* mapAux = malloc(sizeof(mapas));
	mapAux->nombre = string_new();
	strcpy(mapAux->nombre,nomMapa);

	mapAux->finalizado = 0;
	mapAux->ip = config_get_string_value(metadataMapa, "IP");
	mapAux->puerto = config_get_int_value(metadataMapa,"Puerto");

	mapAux->lista_recursos = list_create();

	return mapAux;
}

void copiarMetadataPoke(char* entrenador, mapas* mapa, char* pokemon , char* dirPokeDex){

	char* pathBillEntrenador = string_new();
	string_append(&pathBillEntrenador,dirPokeDex);
	string_append(&pathBillEntrenador,"/Entrenadores/");
	string_append(&pathBillEntrenador,entrenador);
	string_append(&pathBillEntrenador,"/Dir\ de\ Bill");


	char* pathMetadataPoke = string_new();
	string_append(&pathMetadataPoke,dirPokeDex);
	string_append(&pathMetadataPoke,"/Mapas/");
	string_append(&pathMetadataPoke,mapa->nombre);
	string_append(&pathMetadataPoke,"/PokeNests/");
	string_append(&pathMetadataPoke,pokemon);
	string_append(&pathMetadataPoke,"/");
	string_append(&pathMetadataPoke,pokemon);
	string_append(&pathMetadataPoke,"001.dat"); //TODO: ver como hacer el contador para los .dat

	char* cmd = string_new();
	string_append(&cmd,"cp ");
	string_append(&cmd,pathMetadataPoke);
	string_append(&cmd," '");
	string_append(&cmd,pathBillEntrenador);
	string_append(&cmd,"'");

	system(cmd);

}

void copiarMedallaMapa(char* entrenador, mapas* mapa,char* dirPokeDex){

		char* pathMedallasEntrenador = string_new();
		string_append(&pathMedallasEntrenador,dirPokeDex);
		string_append(&pathMedallasEntrenador,"/Entrenadores/");
		string_append(&pathMedallasEntrenador,entrenador);
		string_append(&pathMedallasEntrenador,"/medallas");


		char* pathMapa = string_new();
		string_append(&pathMapa,dirPokeDex);
		string_append(&pathMapa,"/Mapas/");
		string_append(&pathMapa,mapa->nombre);
		string_append(&pathMapa,"/medalla-");
		string_append(&pathMapa,mapa->nombre);
		string_append(&pathMapa,".jpg ");

		char* cmd = string_new();
		string_append(&cmd,"cp ");
		string_append(&cmd,pathMapa);
		string_append(&cmd,pathMedallasEntrenador);

		system(cmd);
}
