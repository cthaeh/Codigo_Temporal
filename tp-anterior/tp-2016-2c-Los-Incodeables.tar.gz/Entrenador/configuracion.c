/*
 * Configuracion.c
 *
 *  Created on: 16/9/2016
 *      Author: utnso
 */

#include "configuracion.h"

void _list_elements(Mapa *mapa) {
	printf("Nombre Mapa: %s\n",mapa->nombre);
	printf("IP: %s\n",mapa->ip);
	printf("Puerto: %d\n",mapa->puerto);
	printf("Estado finalizado: %d\n",mapa->finalizado);

	int i = 0;
	while (mapa->objetivos[i] != NULL) {
	printf("objetivos: %s\n",mapa->objetivos[i]);
		i++;
	}
}

Entrenador* cargarConfiguracion(char* entrenador,char* dirPokeDex,t_log* logger) {

	char* path = string_new();
	string_append(&path,dirPokeDex);
	string_append(&path,"/Entrenadores/");
	string_append(&path,entrenador);
	string_append(&path,"/metadata");

	Entrenador* ent = malloc(sizeof(Entrenador));
	t_config* metadata = config_create(path);

	if(path==NULL){
		log_error(logger,"No se encontró el archivo de configuración.");
		exit (EXIT_FAILURE);
	}

	char** mapasAux = config_get_array_value(metadata,"hojaDeViaje");

	ent->nombre = config_get_string_value(metadata, "nombre");
	ent->simbolo = config_get_string_value(metadata,"simbolo");
	ent->vidas = config_get_int_value(metadata,"vidas");
	ent->reintentos = config_get_int_value(metadata,"reintentos");
	ent->pos.x = 0;
	ent->pos.y = 0;
	ent->mapas = list_create();

	//Agrego a la Lista los Mapas
	int i = 0;
	while (mapasAux[i] != NULL) {

		list_add(ent->mapas, crearMapa(mapasAux[i], dirPokeDex, metadata, logger));
		i++;
	}

	//TODO
	//config_destroy(metadata); lo tengo que sacar porque sino me borra los datos del entrenador. No entiendo por que.

	return ent;
}

Mapa* crearMapa(char* nomMapa, char* dirPokeDex, t_config* metadata, t_log* logger){

	char* path = string_new();
	string_append(&path,dirPokeDex);
	string_append(&path,"/Mapas/");
	string_append(&path,nomMapa);
	string_append(&path,"/metadata");
	t_config* metadataMapa = config_create(path);

	if(path==NULL){
		log_error(logger,"No se encontró el archivo de configuración del Mapa ");
		log_error(logger, nomMapa);
		exit (EXIT_FAILURE);
	}

	//Creo un puntero a Mapa
	Mapa* mapAux = malloc(sizeof(Mapa));
	//Objetivos para obtener objetivos de mapa, Inicializo como string objetivos.
	char* objetivos = string_new();

	//Armo el string a buscar:
	string_append(&objetivos, "obj[");
	string_append(&objetivos, nomMapa);
	string_append(&objetivos, "]\0");

	//Obtengo el array de objetivos,
	char** obj = config_get_array_value(metadata, objetivos);

	//Almaceno nombre de mapa en mi puntero a Mapa
	mapAux->nombre = string_new();
	strcpy(mapAux->nombre,nomMapa);

	//al no saber cuanto son hago un malloc a objetivos y se lo asigno a objetivos de Mapa
	mapAux->objetivos = malloc(sizeof(obj));
	mapAux->objetivos = obj;

	mapAux->finalizado = 0;
	mapAux->ip = config_get_string_value(metadataMapa, "IP");
	mapAux->puerto = config_get_int_value(metadataMapa,"Puerto");

	//TODO
	//mapAux->lista_recursos; no se aca como cargar esto realmente, para seguir con las pruebas le mando lo que armo Diego para probar.


	recursos rec_aux,rec_aux2;
	rec_aux.atrapado = 0;
	rec_aux.pokemon = 'P';
	rec_aux.pokepos.x = 100;
	rec_aux.pokepos.y = 100;

	rec_aux2.atrapado = 0;
	rec_aux2.pokemon = 'C';
	rec_aux2.pokepos.x = 100;
	rec_aux2.pokepos.y = 100;

	mapAux->lista_recursos = list_create();
	list_add(mapAux->lista_recursos, &rec_aux);
	list_add(mapAux->lista_recursos, &rec_aux2);

	//Retorno Mapa con TODOS los Datos
	return mapAux;
}

