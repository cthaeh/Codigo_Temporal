#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <lbsockets/servidor.h>
#include <lbsockets/comunes.h>

#define OSADA_BLOCK_SIZE 64
#define OSADA_FILENAME_LENGTH 17
#define OSADA_MAX_FILE_TABLE 2048

typedef unsigned char osada_block[OSADA_BLOCK_SIZE];
typedef uint32_t osada_block_pointer;

typedef struct {
	unsigned char magic_number[7]; // OSADAFS
	uint8_t version;
	uint32_t fs_blocks; // total amount of blocks
	uint32_t bitmap_blocks; // bitmap size in blocks
	uint32_t allocations_table_offset; // allocations table's first block number
	uint32_t data_blocks; // amount of data blocks
	unsigned char padding[40]; // useless bytes just to complete the block size
} osada_header;

typedef enum __attribute__((packed)) {
    DELETED = '\0',
    REGULAR = '\1',
    DIRECTORY = '\2',
} osada_file_state;

typedef struct {
	osada_file_state state;
	unsigned char fname[OSADA_FILENAME_LENGTH];
	uint16_t parent_directory;
	uint32_t file_size;
	uint32_t lastmod;
	osada_block_pointer first_block;
} osada_file;


int main(int argc, char *argv[]) {

	int socketServidor;				 /* Descriptor del socket servidor */
	int socketCliente[MAX_CLIENTES]; /* Descriptores de sockets con clientes */
	int numeroClientes = 0;			 /* Número clientes conectados */
	fd_set descriptoresLectura;		 /* Descriptores de interes para select() */
	int maximo;						 /* Número de descriptor más grande */
	int in;							 /* Para bubles */

	pthread_t osadear;

	socketServidor = Abre_Socket_Inet(atoi(argv[1]));
	if (socketServidor == -1)
	{
		perror ("Error al abrir servidor");
		exit (-1);
	}

	/* Bucle infinito.
		 * Se atiende a si hay más clientes para conectar y a los mensajes enviados
		 * por los clientes ya conectados */
		while (1)
		{
			/* Cuando un cliente cierre la conexión, se pondrá un -1 en su descriptor
			 * de socket dentro del array socketCliente. La función compactaClaves()
			 * eliminará dichos -1 de la tabla, haciéndola más pequeña.
			 *
			 * Se eliminan TODOs los clientes que hayan cerrado la conexión */
			compactaClaves (socketCliente, &numeroClientes);

			/* Se inicializa descriptoresLectura */
			FD_ZERO (&descriptoresLectura);

			/* Se añade para select() el socket servidor */
			FD_SET (socketServidor, &descriptoresLectura);

			/* Se añaden para select() los sockets con los clientes ya conectados */

			for (in=0; in<numeroClientes; in++)
				FD_SET (socketCliente[in], &descriptoresLectura);

			/* Se el valor del descriptor más grande. Si no hay ningún cliente,
			 * devolverá 0 */
			maximo = dameMaximo (socketCliente, numeroClientes);

			if (maximo < socketServidor)
				maximo = socketServidor;

			/* Espera indefinida hasta que alguno de los descriptores tenga algo
			 * que decir: un nuevo cliente o un cliente ya conectado que envía un
			 * mensaje */
			select (maximo + 1, &descriptoresLectura, NULL, NULL, NULL);

			/* Se comprueba si algún cliente nuevo desea conectarse y se le
			 * admite */
			if (FD_ISSET (socketServidor, &descriptoresLectura)) {
				nuevoCliente (socketServidor, socketCliente, &numeroClientes);
				//pthread_create(&osadear, NULL, (void*) archivar, argv[1]);
				//TODO hacer algo con osada
			}
		}

	return EXIT_SUCCESS;
}
