/*
 * osadaReader.h
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */

#ifndef OSADAREADER_H_
#define OSADAREADER_H_

typedef struct {
	char identificador[7];
	char version[1];
	int tamanio_fs;
	int tamanio_bitmap;
	int inicio_tabla_asignaciones;
	int tamanio_datos;
	char relleno[40];
} t_osada_header;

typedef struct  {
	char estado;
	char nombre_archivo[17];
	char bloque_padre[2];
	int  tamanio_archivo;
	char fecha_ultima_modif[4];
	int  bloque_inicial;
} t_osada_tabla_archivos;

struct osada_reader {
	t_osada_header* header;
	t_osada_tabla_archivos * tabla_archivos;
};

#endif /* OSADAREADER_H_ */
