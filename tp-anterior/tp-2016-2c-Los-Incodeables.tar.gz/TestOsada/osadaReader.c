//CODIGOS
//200 Cliente a Servidor - Pedido de directorio
//300 Servidor a Cliente - Directorio encontrado
//400 Servidor a Cliente - Directorio no encontrado

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <commons/string.h>
#include <sys/mman.h>
#include "osadaReader.h"
#include <fcntl.h>
#include <string.h>
#include <stddef.h>
#include <errno.h>
#include <lbsockets/servidor.h>
#include <lbsockets/comunes.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>


#define OSADA_BLOCK_SIZE 64
#define OSADA_FILENAME_LENGTH 17
#define OSADA_MAX_FILE_TABLE 2048

typedef unsigned char osada_block[OSADA_BLOCK_SIZE];
typedef uint32_t osada_block_pointer;

typedef struct {
	unsigned char magic_number[7]; // OSADAFS
	uint8_t version;
	uint32_t fs_blocks; // total amount of blocks
	uint32_t bitmap_blocks; // bitmap size in blocks
	uint32_t allocations_table_offset; // allocations table's first block number
	uint32_t data_blocks; // amount of data blocks
	unsigned char padding[40]; // useless bytes just to complete the block size
} osada_header;

typedef enum __attribute__((packed)) {
    DELETED = '\0',
    REGULAR = '\1',
    DIRECTORY = '\2',
} osada_file_state;

typedef struct {
	osada_file_state state;
	unsigned char fname[OSADA_FILENAME_LENGTH];
	uint16_t parent_directory;
	uint32_t file_size;
	uint32_t lastmod;
	osada_block_pointer first_block;
} osada_file;

typedef struct {
	int socket;
	char* archivo;
} cliente;

void* archivar(cliente* cliente);

int longitudMensaje = 1000;

int main(int argc, char *argv[]) {

	int socketServidor;				 /* Descriptor del socket servidor */
	int socketCliente[MAX_CLIENTES]; /* Descriptores de sockets con clientes */
	int numeroClientes = 0;			 /* Número clientes conectados */
	fd_set descriptoresLectura;		 /* Descriptores de interes para select() */
	int maximo;						 /* Número de descriptor más grande */
	int in;							 /* Para bubles */

	pthread_t osadear;

	socketServidor = Abre_Socket_Inet(atoi(argv[2]));
	if (socketServidor == -1)
	{
		perror ("Error al abrir servidor");
		exit (-1);
	}

	/* Bucle infinito.
		 * Se atiende a si hay más clientes para conectar y a los mensajes enviados
		 * por los clientes ya conectados */
		while (1)
		{
			char mensaje[longitudMensaje];
			/* Cuando un cliente cierre la conexión, se pondrá un -1 en su descriptor
			 * de socket dentro del array socketCliente. La función compactaClaves()
			 * eliminará dichos -1 de la tabla, haciéndola más pequeña.
			 *
			 * Se eliminan TODOs los clientes que hayan cerrado la conexión */
			compactaClaves (socketCliente, &numeroClientes);

			/* Se inicializa descriptoresLectura */
			FD_ZERO (&descriptoresLectura);

			/* Se añade para select() el socket servidor */
			FD_SET (socketServidor, &descriptoresLectura);

			/* Se añaden para select() los sockets con los clientes ya conectados */

			for (in=0; in<numeroClientes; in++)
				FD_SET (socketCliente[in], &descriptoresLectura);

			/* Se el valor del descriptor más grande. Si no hay ningún cliente,
			 * devolverá 0 */
			maximo = dameMaximo (socketCliente, numeroClientes);

			if (maximo < socketServidor)
				maximo = socketServidor;

			/* Espera indefinida hasta que alguno de los descriptores tenga algo
			 * que decir: un nuevo cliente o un cliente ya conectado que envía un
			 * mensaje */
			select (maximo + 1, &descriptoresLectura, NULL, NULL, NULL);

			/* Se comprueba si algún cliente nuevo desea conectarse y se le
			 * admite */
			if (FD_ISSET (socketServidor, &descriptoresLectura)) {
				int socket_cli = nuevoCliente(socketServidor, socketCliente, &numeroClientes);

				cliente* cliente = malloc(sizeof(cliente));
				cliente->socket = socket_cli;
				cliente->archivo = argv[1];

				pthread_create(&osadear, NULL, (void*) archivar, cliente);
			}
		}


	return EXIT_SUCCESS;
}

void* archivar(cliente* cliente) {
	printf("se creo el hilo correctamente \n");
	osada_header headerOsada;
		osada_file tabla_archivos[OSADA_MAX_FILE_TABLE];

		int fd_osada = open(cliente->archivo, O_RDWR);
		struct stat osadaFileStat;
		fstat(fd_osada, &osadaFileStat);
		int* pmap_osada = mmap(0, osadaFileStat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_osada, 0);

		memcpy(&headerOsada,((char*)pmap_osada), sizeof(headerOsada));

		printf("\n\n FILESYSTEM: %s\n", headerOsada.magic_number);
		printf("VERSION: %d\n", headerOsada.version);
		printf("TAMANIO EN BLOQUES DEL FS: %d\n", headerOsada.fs_blocks);
		printf("TAMANIO EN BLOQUES DEL BITMAP: %d\n", headerOsada.bitmap_blocks);
		printf("BLOQUE INICIO TABLA ASIGNACIONES: %d\n", headerOsada.allocations_table_offset);
		printf("TAMANIO EN BLOQUES DE DATOS: %d\n", headerOsada.data_blocks);

		uint32_t len_bitmap = headerOsada.fs_blocks / 8 / OSADA_BLOCK_SIZE;

		unsigned char bitmap[len_bitmap];

		memcpy(&bitmap, ((char *)pmap_osada), sizeof(bitmap));

		int i = 0;

		int tamanio_tabla_asignaciones = (headerOsada.fs_blocks - 1 - len_bitmap - 1024) * 4 / OSADA_BLOCK_SIZE;
		printf("tamanio_tabla_asign:%d\n", tamanio_tabla_asignaciones);

		uint32_t tabla_asignaciones[tamanio_tabla_asignaciones];

		uint32_t bloque_datos[headerOsada.data_blocks];

		memcpy(&tabla_asignaciones, ((char *)pmap_osada) + headerOsada.allocations_table_offset, sizeof(tabla_asignaciones));
		memcpy(&tabla_archivos, ((char *)pmap_osada), sizeof(tabla_archivos));
		memcpy(&bloque_datos, ((char *)pmap_osada), sizeof(bloque_datos));

		for (i = 0; i < OSADA_MAX_FILE_TABLE; i++) {

			if (tabla_archivos[i].state == DIRECTORY){
				printf("DIRECTORIO: %s\n", tabla_archivos[i].fname);
				printf("tamanio_directorio: %d\n", tabla_archivos[i].file_size);
				printf("dir padre: %s\n", tabla_archivos[tabla_archivos[i].parent_directory].fname);
			}
			/*else if (tabla_archivos[i].state == REGULAR){
				printf("ARCHIVO: %s\n", tabla_archivos[i].fname);
				printf("tamanio_archivo: %d\n", tabla_archivos[i].file_size);

				int tamanio_archivo = tabla_archivos[i].file_size;
				int j = 0;
				int primer_bloque = tabla_archivos[i].first_block;
				printf("primer_bloque:%d\n", primer_bloque);
				int sgte_bloque = tabla_asignaciones[primer_bloque];

				printf("sgte_bloque:%d\n", sgte_bloque);

				for(j = 0; j < tamanio_archivo; j++){
					if (j == 0){
						printf("datos: %d\n", bloque_datos[primer_bloque]);
					} else {
						sgte_bloque = tabla_asignaciones[sgte_bloque];
					}
				}
			}*/
		}


		while(1){

			char* mensajeACliente = string_new();
			char* codigo = string_new();
			char* nombre = string_new();
			char* padre = string_new();
			int flag = leeSocket(cliente->socket, &longitudMensaje, sizeof(size_t));
			char mensaje[longitudMensaje];
			read(cliente->socket, &mensaje, sizeof(mensaje));

			if(flag > 0){

				codigo = strtok(mensaje, ";");
				printf("CODIGO: %s", codigo);

				switch(atoi(codigo)){
				case 200:
					nombre = strtok(NULL, ";");
					padre = strtok(NULL, ";");
					int encontrado = 0;
					int esDir = 1;

					for (i = 0; i < OSADA_MAX_FILE_TABLE; i++) {

						//DIR RAIZ
						if (string_is_empty(nombre) && string_is_empty(padre)){
							string_append(&mensajeACliente, "300;");

							int j = 0;
							for (j = 0; j < OSADA_MAX_FILE_TABLE; j++){
								if (string_is_empty(tabla_archivos[tabla_archivos[j].parent_directory].fname)){
									string_append(&mensajeACliente, tabla_archivos[j].fname);
									string_append(&mensajeACliente, ";");
								}
							}
							break;
						}
						else if (strcmp(tabla_archivos[i].fname, nombre) == 0){
							//Encontre coincidencia por nombre de archivo o directorio
							//Me fijo si el padre es el mismo para evitar conflicto con nombres
							int posParent = tabla_archivos[i].parent_directory;
							if (strcmp(tabla_archivos[posParent].fname, padre) == 0){
								string_append(&mensajeACliente, "300;");

								if (tabla_archivos[i].state == DIRECTORY){
									string_append(&mensajeACliente, "DIR");
								}
								else {
									string_append(&mensajeACliente, "ARCH");
									esDir = 0;
								}
								encontrado = 1;
								break;
							}
						}
					}

					if (!encontrado){
						string_append(&mensajeACliente, "400;");
					}

					write(cliente->socket,mensajeACliente,sizeof(char[longitudMensaje]));

					break;
				}
			}
		}
}
