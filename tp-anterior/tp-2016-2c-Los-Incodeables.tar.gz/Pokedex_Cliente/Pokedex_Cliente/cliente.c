//CODIGOS
//200 Cliente a Servidor - Pedido de directorio
//300 Servidor a Cliente - Directorio encontrado
//400 Servidor a Cliente - Directorio no encontrado

#include <stddef.h>
#include <stdlib.h>
#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <lbsockets/cliente.h>
#include <lbsockets/comunes.h>
#include <commons/log.h>
#include <commons/string.h>
#include <sys/mman.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

int Abre_Conexion_Inet(char *p, int ps);
char* extraer_entre(char *str, const char *p1, const char *p2);
int devolver_cantidad_coincidencias(char* str, char separator);

//metadata ash
int fd_metadata_ash;
int* pmap_ash;
struct stat ashStat;

//metadata pueblo paleta
int fd_metadata_pueblo_paleta;
int* pmap_pueblo_paleta;
struct stat puebloPaletaStat;

int socket_server;

/*
 * @DESC
 *  Esta función va a ser llamada cuando a la biblioteca de FUSE le llege un pedido
 * para obtener la metadata de un archivo/directorio. Esto puede ser tamaño, tipo,
 * permisos, dueño, etc ...
 *
 * @PARAMETROS
 * 		path - El path es relativo al punto de montaje y es la forma mediante la cual debemos
 * 		       encontrar el archivo o directorio que nos solicitan
 * 		stbuf - Esta esta estructura es la que debemos completar
 *
 * 	@RETURN
 * 		O archivo/directorio fue encontrado. -ENOENT archivo/directorio no encontrado
 */
static int pokedex_getattr(const char *path, struct stat *stbuf) {
	int res = 0;
	char mensaje[1000] = "";
 	char *ppath = malloc(strlen(path) + 1);
 	char *parent = malloc(strlen(path) + 1);

	memset(stbuf, 0, sizeof(struct stat));

	printf("GETATTR: %s \n",path);

	//Si path es igual a "/" nos estan pidiendo los atributos del punto de montaje

	if (strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
	}
	else if (strcmp(path, "/Pokemones") == 0){
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
	}
	else {
	 	int l = 0;
	 	int count = 0;
	 	ppath = strstr(path, "/");
	 	do {
	 	 	count = devolver_cantidad_coincidencias(ppath, '/');
	 	 	if (count == 2){
	 	 	 	parent = extraer_entre(ppath,"/","/");
	 	 	}
	 	    l = strlen(ppath) + 1;
	 	    path = &path[strlen(path)-l+2];
	 	 	ppath = strstr(path, "/");
	 	}while(ppath);

		mensaje[0] = '2';
		mensaje[1] = '0';
		mensaje[2] = '0';
		mensaje[3] = ';';
		memcpy(mensaje + 4, path, strlen(path));
		memcpy(mensaje + strlen(mensaje), ";", 1);
		memcpy(mensaje + strlen(mensaje), parent, strlen(parent));

		int waitingForResponse = NULL;
		char* codigo = string_new();

		size_t longitudMensaje = strlen(mensaje) + 1;

		escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
		escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

		while(waitingForResponse != NULL){
			read(socket_server, &mensaje, sizeof(mensaje));
			if(!string_is_empty(mensaje))
				codigo = strtok(mensaje, ";");
				switch(atoi(codigo)){

					case 300:
						waitingForResponse = 1;
						stbuf->st_mode = S_IFDIR | 0755;
						stbuf->st_nlink = 2;
						break;
					case 400:
						waitingForResponse = 1;
						res = -ENOENT;
						break;
				}
		}

		free(ppath);
		free(parent);

	}
	return res;
}

/*
 * @DESC
 *  Esta función va a ser llamada cuando a la biblioteca de FUSE le llege un pedido
 * para obtener la lista de archivos o directorios que se encuentra dentro de un directorio
 *
 * @PARAMETROS
 * 		path - El path es relativo al punto de montaje y es la forma mediante la cual debemos
 * 		       encontrar el archivo o directorio que nos solicitan
 * 		buf - Este es un buffer donde se colocaran los nombres de los archivos y directorios
 * 		      que esten dentro del directorio indicado por el path
 * 		filler - Este es un puntero a una función, la cual sabe como guardar una cadena dentro
 * 		         del campo buf
 *
 * 	@RETURN
 * 		O directorio fue encontrado. -ENOENT directorio no encontrado
 */
static int pokedex_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {

	// "." y ".." son entradas validas, la primera es una referencia al directorio donde estamos parados
	// y la segunda indica el directorio padre

	int res = 0;
	char mensaje[1000] = "";

	(void) offset;
	(void) fi;

	if (strcmp(path, "/") == 0) {
		filler(buf, "Pokemones", NULL, 0);

		char *ppath = malloc(strlen(path) + 1);
		char *parent = malloc(strlen(path) + 1);
		int l = 0;
		int count = 0;
		ppath = strstr(path, "/");
		do{
			count = devolver_cantidad_coincidencias(ppath, '/');
			if (count == 2){
				parent = extraer_entre(ppath,"/","/");
			}
			l = strlen(ppath) + 1;
			path = &path[strlen(path)-l+2];
			ppath = strstr(path, "/");
		}while(ppath);

		mensaje[0] = '2';
		mensaje[1] = '0';
		mensaje[2] = '0';
		mensaje[3] = ';';
		memcpy(mensaje + 4, path, strlen(path));
		memcpy(mensaje + strlen(mensaje), ";", 1);
		memcpy(mensaje + strlen(mensaje), parent, strlen(parent));

		size_t longitudMensaje = strlen(mensaje) + 1;

		escribeSocket(socket_server,&longitudMensaje,sizeof(size_t));
		escribeSocket(socket_server,mensaje,sizeof(char[longitudMensaje]));

		free(ppath);
		free(parent);
	}

 	return res;
}

/*
 * @DESC
 *  Esta función va a ser llamada cuando a la biblioteca de FUSE le llege un pedido
 * para tratar de abrir un archivo
 *
 * @PARAMETROS
 * 		path - El path es relativo al punto de montaje y es la forma mediante la cual debemos
 * 		       encontrar el archivo o directorio que nos solicitan
 * 		fi - es una estructura que contiene la metadata del archivo indicado en el path
 *
 * 	@RETURN
 * 		O archivo fue encontrado. -EACCES archivo no es accesible
 */
static int pokedex_open(const char *path, struct fuse_file_info *fi) {

	//TODO: implementar si es necesario

	return -ENOENT;
}

/*
 * @DESC
 *  Esta función va a ser llamada cuando a la biblioteca de FUSE le llege un pedido
 * para obtener el contenido de un archivo
 *
 * @PARAMETROS
 * 		path - El path es relativo al punto de montaje y es la forma mediante la cual debemos
 * 		       encontrar el archivo o directorio que nos solicitan
 * 		buf - Este es el buffer donde se va a guardar el contenido solicitado
 * 		size - Nos indica cuanto tenemos que leer
 * 		offset - A partir de que posicion del archivo tenemos que leer
 *
 * 	@RETURN
 * 		Si se usa el parametro direct_io los valores de retorno son 0 si  elarchivo fue encontrado
 * 		o -ENOENT si ocurrio un error. Si el parametro direct_io no esta presente se retorna
 * 		la cantidad de bytes leidos o -ENOENT si ocurrio un error. ( Este comportamiento es igual
 * 		para la funcion write )
 */
static int pokedex_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi) {

	if (strcmp(path, "/Pokedex/Entrenadores/Ash/metadata") == 0) {
		memcpy(buf,((char*)pmap_ash + offset),size);
	}

	if (strcmp(path, "/Pokedex/Mapas/PuebloPaleta/metadata") == 0){
		memcpy(buf,((char*)pmap_pueblo_paleta + offset),size);
	}

	return size;

}

static struct fuse_operations pokedex_oper = {
	.getattr = pokedex_getattr,
	.readdir = pokedex_readdir,
	.read = pokedex_read,
};

/* path ip puerto */
int main(int argc, char* argv[]){

	int puertoSkt;

	puertoSkt = atoi(argv[3]);
	socket_server = Abre_Conexion_Inet(argv[2], puertoSkt);

    struct fuse_args args = FUSE_ARGS_INIT(0, NULL);
    int i;

    for(i = 0; i < argc; i++) {
            if (i == 0 || i == 1){
            	fuse_opt_add_arg(&args, argv[i]);
            }
    }

	fd_metadata_ash = open("/home/utnso/git/tp-2016-2c-Los-Incodeables/PokeDex_Local/Entrenadores/Ash/metadata", O_RDWR);
	fstat(fd_metadata_ash, &ashStat);
	pmap_ash = mmap(0, ashStat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_metadata_ash, 0);

	fd_metadata_pueblo_paleta = open("/home/utnso/git/tp-2016-2c-Los-Incodeables/PokeDex_Local/Mapas/PuebloPaleta/metadata", O_RDWR);
	fstat(fd_metadata_pueblo_paleta, &puebloPaletaStat);
	pmap_pueblo_paleta = mmap(0, puebloPaletaStat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_metadata_pueblo_paleta, 0);

	return fuse_main(args.argc, args.argv, &pokedex_oper, NULL);
}

char* extraer_entre(char *str, const char *p1, const char *p2) {
  const char *i1 = strstr(str, p1);
  if(i1 != NULL)
  {
    const size_t pl1 = strlen(p1);
    const char *i2 = strstr(i1 + pl1, p2);
    if(p2 != NULL)
    {
     /* Found both markers, extract text. */
     const size_t mlen = i2 - (i1 + pl1);
     char *ret = malloc(mlen + 1);
     if(ret != NULL)
     {
       memcpy(ret, i1 + pl1, mlen);
       ret[mlen] = '\0';
       return ret;
     }
    }
  }
  return NULL;
}

int devolver_cantidad_coincidencias(char* str, char separator){
	int count = 0;
	if (str == NULL)
		return 0;

	for (count = 0; str[count]; str[count]=='/' ? count++ : *str++);

	return count;
}











